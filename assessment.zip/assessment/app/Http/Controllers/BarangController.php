<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\barang;

class BarangController extends Controller
{
    public function index(){
        $data = barang::all();
        return view('dataBarang',compact('data'));
    }

    public function create()
    {
        return view('barang');
    }

    public function tampilbarang($id){

        $data = barang::find($id);
        return view('barang', compact('data'));
    }

    public function editbarang(Request $request, $id){
        $data = barang::find($id);
        $data->update($request->all());

        return redirect()->route('databarang')->with('success', 'Data berhasil di update');
    }

    // public function deletekerja($id){
    //     riwayatkerja::where('id',$id)->delete();
    //     alert('Hapus Data','Data Berhasil Dihapus', 'success');
    //     return redirect()->route('pekerjaan');
    // }

    public function deletebarang($id)
    {
        $data = barang::find($id);
        $data->delete();
        return redirect()->route('databarang');
    }

    public function store(Request $request)
    {
        $request->validate([
            'KodeBarang' => 'required|numeric',
            'NamaBarang' => 'required',
            'Satuan' => 'required|numeric',
            'HargaSatuan' => 'required|numeric',
            'Stok' => 'required',
        ], 
        [
            'KodeBarang.numeric' => 'Kode Barang harus diisi berupa angka.',
            'NamaBarang.required' => 'Jabatan harus diisi.',
            'Satuan.numeric' => 'Satuan harus diisi berupa angka.',
            'HargaSatuan.numeric' => 'Harga harus diisi berupa angka.',
            'Stok.numeric' => 'Stok harus diisi berupa angka.',
        ]);
    
        // Jika validasi berhasil, simpan data ke database
        barang::create($request->all());
    
        // Redirect ke halaman lain atau kembali ke form dengan pesan sukses
        return redirect()->route('databarang')->with('success', 'Data berhasil ditambah');
    }
}

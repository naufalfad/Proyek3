<!doctype html>
<html lang="en">
<body>

<div class="container mt-5">
    <br>
    {{-- <h2 class="mb-4">Tambah Pengangguran</h2> --}}

<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/app.css')}}">

    @if(isset($data))
        <h2 class="mb-4">Edit Barang</h2>
        <form action="{{ route('editbarang', $data->id) }}" method="post" enctype="multipart/form-data">
        @method('POST') {{-- Use PUT method for updating data --}}
    @else
        <h2 class="mb-4">Tambah Barang</h2>
        <form action="{{ route('tambahbarang.store') }}" method="post" enctype="multipart/form-data">
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            Terdapat beberapa kesalahan input. Silakan periksa dan coba lagi.
        </div>
    @endif

    {{-- <form action="{{ route('insertdata') }}" method="post" enctype="multipart/form-data"> --}}
        @csrf

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="KodeBarang">Kode Barang</label>
                    <input type="text" class="form-control" id="KodeBarang" name="KodeBarang" value="{{ $data->KodeBarang ?? old('KodeBarang') }}" placeholder="Kode Barang">
                    @error('Kode Barang')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="NamaBarang">Nama Barang</label>
                    <input type="text" class="form-control" id="KodeBarang" name="NamaBarang" value="{{ $data->NamaBarang ?? old('NamaBarang') }}" placeholder="Nama Barang">
                    @error('Nama Barang')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="Satuan">Satuan</label>
                    <input type="text" class="form-control" id="Satuan" name="Satuan" value="{{ $data->Satuan ?? old('Satuan') }}" placeholder="Satuan">
                    @error('Satuan')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="HargaSatuan">Harga Satuan</label>
                    <input type="text" class="form-control" id="HargaSatuan" name="HargaSatuan" value="{{ $data->HargaSatuan ?? old('HargaSatuan') }}" placeholder="Harga Satuan">
                    @error('Harga Satuan')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="Stok">Stok</label>
                    <input type="text" class="form-control" id="Stok" name="Stok" value="{{ $data->Stok ?? old('Stok') }}" placeholder="Stok">
                    @error('Stok')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary">Submmit</button>
                </div>
            </div>
        </div>

    </form>
    {{-- <a type="submit" href="/pengangguran" class="btn btn-secondary mt-3" style="margin-bottom:10px">Prev</a> --}}
</div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script>
    // Jika form berhasil disubmit
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('#formTambahPengangguran'); // Menggunakan ID "formTambahPengangguran"
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Menghentikan form dari pengiriman otomatis

            // Ambil data dari form
            const formData = new FormData(form);

            // Kirim data ke server menggunakan AJAX
            $.ajax({
                url: "{{ route('tambahbarang.store') }}", // Ganti sesuai dengan rute Anda
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    // Handle respons dari server, jika diperlukan
                    // Misalnya, Anda dapat menampilkan pesan sukses atau pengalihkan pengguna
                    window.location.href = "{{ route('databarang') }}";
                },
                error: function(xhr, textStatus, errorThrown) {
                    // Handle error jika terjadi kesalahan
                    console.error(xhr.responseText);
                    alert('Terjadi kesalahan saat menyimpan data.');
                }
            });
        });
</script>

</body>
<!doctype html>
<html lang="en">
<body>

<div class="container mt-5">
    <br>
    

<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <?php if(isset($data)): ?>
        <h2 class="mb-4">Edit Barang</h2>
        <form action="<?php echo e(route('editbarang', $data->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('POST'); ?> 
    <?php else: ?>
        <h2 class="mb-4">Tambah Barang</h2>
        <form action="<?php echo e(route('tambahbarang.store')); ?>" method="post" enctype="multipart/form-data">
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            Terdapat beberapa kesalahan input. Silakan periksa dan coba lagi.
        </div>
    <?php endif; ?>

    
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="KodeBarang">Kode Barang</label>
                    <input type="text" class="form-control" id="KodeBarang" name="KodeBarang" value="<?php echo e($data->KodeBarang ?? old('KodeBarang')); ?>" placeholder="Kode Barang">
                    <?php $__errorArgs = ['Kode Barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="NamaBarang">Nama Barang</label>
                    <input type="text" class="form-control" id="KodeBarang" name="NamaBarang" value="<?php echo e($data->NamaBarang ?? old('NamaBarang')); ?>" placeholder="Nama Barang">
                    <?php $__errorArgs = ['Nama Barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="Satuan">Satuan</label>
                    <input type="text" class="form-control" id="Satuan" name="Satuan" value="<?php echo e($data->Satuan ?? old('Satuan')); ?>" placeholder="Satuan">
                    <?php $__errorArgs = ['Satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="HargaSatuan">Harga Satuan</label>
                    <input type="text" class="form-control" id="HargaSatuan" name="HargaSatuan" value="<?php echo e($data->HargaSatuan ?? old('HargaSatuan')); ?>" placeholder="Harga Satuan">
                    <?php $__errorArgs = ['Harga Satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="Stok">Stok</label>
                    <input type="text" class="form-control" id="Stok" name="Stok" value="<?php echo e($data->Stok ?? old('Stok')); ?>" placeholder="Stok">
                    <?php $__errorArgs = ['Stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary">Submmit</button>
                </div>
            </div>
        </div>

    </form>
    
</div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script>
    // Jika form berhasil disubmit
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('#formTambahPengangguran'); // Menggunakan ID "formTambahPengangguran"
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Menghentikan form dari pengiriman otomatis

            // Ambil data dari form
            const formData = new FormData(form);

            // Kirim data ke server menggunakan AJAX
            $.ajax({
                url: "<?php echo e(route('tambahbarang.store')); ?>", // Ganti sesuai dengan rute Anda
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    // Handle respons dari server, jika diperlukan
                    // Misalnya, Anda dapat menampilkan pesan sukses atau pengalihkan pengguna
                    window.location.href = "<?php echo e(route('databarang')); ?>";
                },
                error: function(xhr, textStatus, errorThrown) {
                    // Handle error jika terjadi kesalahan
                    console.error(xhr.responseText);
                    alert('Terjadi kesalahan saat menyimpan data.');
                }
            });
        });
</script>

</body><?php /**PATH D:\Semester3\Proyek3\assessment\resources\views/barang.blade.php ENDPATH**/ ?>
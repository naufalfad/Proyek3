<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BarangController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/databarang', [BarangController::class, 'index'])->name('databarang');
Route::get('/tambahbarang', [BarangController::class, 'create'])->name('tambahbarang');
Route::post('/tambahbarang/store', [BarangController::class, 'store'])->name('tambahbarang.store');
Route::post('/insertbarang', [BarangController::class, 'insertbarang'])->name('insertbarang');
Route::get('/tampilbarang/{id}', [BarangController::class, 'tampilbarang'])->name('tampilbarang');
Route::post('/editbarang/{id}', [BarangController::class, 'editbarang'])->name('editbarang');
Route::get('/deletebarang/{id}', [BarangController::class, 'deletebarang'])->name('deletebarang');